package com.mycompany.interfaces;

import com.mycompany.clases.Clientes;
import java.util.List;

public interface DAOClientes {
    public void registrar(Clientes cliente) throws Exception;
    public void modificar(Clientes cliente) throws Exception;
    public void sancionar(Clientes cliente) throws Exception;
    public void eliminar(int idCliente) throws Exception;
    public List<Clientes> listar(String nombres) throws Exception;
    public Clientes getUserById(int idCliente) throws Exception;
}