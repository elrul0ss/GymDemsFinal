package com.mycompany.clases;

public class Clientes {
    private int id;
    private String Nombre;
    private String apellidoP;
    private String apellidoM;
    private String domicilio;
    private String telefono;
    private int sanciones;
    private int sanc_money; //AUN NO TOMAR EN CUENTA

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public void setApellidoP(String apellidoP) {
        this.apellidoP = apellidoP;
    }

    public void setApellidoM(String apellidoM) {
        this.apellidoM = apellidoM;
    }

    public void setDomicilio(String domicilio) {
        this.domicilio = domicilio;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setSanciones(int sanciones) {
        this.sanciones = sanciones;
    }

    public void setSanc_money(int sanc_money) {
        this.sanc_money = sanc_money;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return Nombre;
    }

    public String getApellidoP() {
        return apellidoP;
    }

    public String getApellidoM() {
        return apellidoM;
    }

    public String getDomicilio() {
        return domicilio;
    }

    public String getTelefono() {
        return telefono;
    }

    public int getSanciones() {
        return sanciones;
    }

    public int getSanc_money() {
        return sanc_money;
    }
}
