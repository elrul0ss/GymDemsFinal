package com.mycompany.ilib;

import com.mycompany.db.Database;
import com.mycompany.interfaces.DAOBooks;
import com.mycompany.clases.Productos;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DAOBooksImpl extends Database implements DAOBooks {

    @Override
    public void registrar(Productos book) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO books(title, date, author, category, edit, lang, pages, description, ejemplares, stock, available) VALUES(?,?,?,?,?,?,?,?,?,?,?);");
            st.setString(1, book.getNombreProducto());
            st.setString(2, book.getFechaIngreso());
            st.setString(3, book.getFechaVencimiento());
            st.setString(4, book.getCategoria());
            st.setString(5, book.getMarca());
            st.setString(6, book.getProveedor());
            st.setString(8, book.getDescripcion());
            st.setString(9, book.getDisponibilidad());
            st.setInt(10, book.getStock());
            st.setInt(11, book.getPrecio());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void modificar(Productos book) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("UPDATE books SET title = ?, date = ?, author = ?, category = ?, edit = ?, lang = ?, pages = ?, description = ?, ejemplares = ?, stock = ?, available = ? WHERE id = ?");
            st.setString(1, book.getNombreProducto());
            st.setString(2, book.getFechaIngreso());
            st.setString(3, book.getFechaVencimiento());
            st.setString(4, book.getCategoria());
            st.setString(5, book.getMarca());
            st.setString(6, book.getProveedor());
            st.setString(8, book.getDescripcion());
            st.setString(9, book.getDisponibilidad());
            st.setInt(10, book.getStock());
            st.setInt(11, book.getPrecio());
            st.setInt(12, book.getId());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void eliminar(int bookId) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("DELETE FROM books WHERE id = ?;");
            st.setInt(1, bookId);
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public List<Productos> listar(String title) throws Exception {
        List<Productos> lista = null;
        try {
            this.Conectar();
            String Query = title.isEmpty() ? "SELECT * FROM books;" : "SELECT * FROM books WHERE title LIKE '%" + title + "%';";
            PreparedStatement st = this.conexion.prepareStatement(Query);
            
            lista = new ArrayList();
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                Productos book = new Productos();
                book.setId(rs.getInt("id"));
                book.setNombreProducto(rs.getString("title"));
                book.setFechaIngreso(rs.getString("date"));
                book.setFechaVencimiento(rs.getString("author"));
                book.setCategoria(rs.getString("category"));
                book.setMarca(rs.getString("edit"));
                book.setProveedor(rs.getString("lang"));
                book.setDescripcion(rs.getString("description"));
                book.setDisponibilidad(rs.getString("ejemplares"));
                book.setStock(rs.getInt("stock"));
                book.setPrecio(rs.getInt("available"));
                lista.add(book);
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return lista;
    }

    @Override
    public Productos getBookById(int bookId) throws Exception {
        Productos book = null;
        
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM books WHERE id = ? LIMIT 1;");
            st.setInt(1, bookId);
            
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                book = new Productos();
                book.setId(rs.getInt("id"));
                book.setNombreProducto(rs.getString("title"));
                book.setFechaIngreso(rs.getString("date"));
                book.setFechaVencimiento(rs.getString("author"));
                book.setCategoria(rs.getString("category"));
                book.setMarca(rs.getString("edit"));
                book.setProveedor(rs.getString("lang"));
                book.setDescripcion(rs.getString("description"));
                book.setDisponibilidad(rs.getString("ejemplares"));
                book.setStock(rs.getInt("stock"));
                book.setPrecio(rs.getInt("available"));
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return book;
    }   
}