package com.mycompany.ilib;

import com.mycompany.db.Database;
import com.mycompany.clases.Productos;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.interfaces.DAOProductos;

public class DAOProductosImpl extends Database implements DAOProductos {

    @Override
    public void registrar(Productos producto) throws Exception {
        try {
            //this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO books(title, date, author, category, edit, lang, pages, description, ejemplares, stock, available) VALUES(?,?,?,?,?,?,?,?,?,?,?);");
            st.setString(1, producto.getNombreProducto());
            st.setString(2, producto.getFechaIngreso());
            st.setString(3, producto.getFechaVencimiento());
            st.setString(4, producto.getCategoria());
            st.setString(5, producto.getMarca());
            st.setString(6, producto.getProveedor());
            st.setString(8, producto.getDescripcion());
            st.setString(9, producto.getDisponibilidad());
            st.setInt(10, producto.getStock());
            st.setInt(11, producto.getPrecio());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            //this.Cerrar();
        }
    }

    @Override
    public void modificar(Productos producto) throws Exception {
        try {
            //this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("UPDATE books SET title = ?, date = ?, author = ?, category = ?, edit = ?, lang = ?, pages = ?, description = ?, ejemplares = ?, stock = ?, available = ? WHERE id = ?");
            st.setString(1, producto.getNombreProducto());
            st.setString(2, producto.getFechaIngreso());
            st.setString(3, producto.getFechaVencimiento());
            st.setString(4, producto.getCategoria());
            st.setString(5, producto.getMarca());
            st.setString(6, producto.getProveedor());
            st.setString(8, producto.getDescripcion());
            st.setString(9, producto.getDisponibilidad());
            st.setInt(10, producto.getStock());
            st.setInt(11, producto.getPrecio());
            st.setInt(12, producto.getId());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            //this.Cerrar();
        }
    }

    @Override
    public void eliminar(int idProducto) throws Exception {
        try {
            //this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("DELETE FROM books WHERE id = ?;");
            st.setInt(1, idProducto);
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            //this.Cerrar();
        }
    }

    @Override
    public List<Productos> listar(String nombre) throws Exception {
        List<Productos> lista = null;
        try {
            //this.Conectar();
            String Query = nombre.isEmpty() ? "SELECT * FROM books;" : "SELECT * FROM books WHERE title LIKE '%" + nombre + "%';";
            PreparedStatement st = this.conexion.prepareStatement(Query);
            
            lista = new ArrayList();
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                Productos producto = new Productos();
                producto.setId(rs.getInt("id"));
                producto.setNombreProducto(rs.getString("title"));
                producto.setFechaIngreso(rs.getString("date"));
                producto.setFechaVencimiento(rs.getString("author"));
                producto.setCategoria(rs.getString("category"));
                producto.setMarca(rs.getString("edit"));
                producto.setProveedor(rs.getString("lang"));
                producto.setDescripcion(rs.getString("description"));
                producto.setDisponibilidad(rs.getString("ejemplares"));
                producto.setStock(rs.getInt("stock"));
                producto.setPrecio(rs.getInt("available"));
                lista.add(producto);
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            //this.Cerrar();
        }
        return lista;
    }

    @Override
    public Productos getBookById(int idProducto) throws Exception {
        Productos producto = null;
        
        try {
            //this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM books WHERE id = ? LIMIT 1;");
            st.setInt(1, idProducto);
            
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                producto = new Productos();
                producto.setId(rs.getInt("id"));
                producto.setNombreProducto(rs.getString("title"));
                producto.setFechaIngreso(rs.getString("date"));
                producto.setFechaVencimiento(rs.getString("author"));
                producto.setCategoria(rs.getString("category"));
                producto.setMarca(rs.getString("edit"));
                producto.setProveedor(rs.getString("lang"));
                producto.setDescripcion(rs.getString("description"));
                producto.setDisponibilidad(rs.getString("ejemplares"));
                producto.setStock(rs.getInt("stock"));
                producto.setPrecio(rs.getInt("available"));
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            //this.Cerrar();
        }
        return producto;
    }   
}