package com.mycompany.ilib;

import com.mycompany.db.Database;
import com.mycompany.clases.Clientes;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.mycompany.interfaces.DAOClientes;

public class DAOClientesImpl extends Database implements DAOClientes {

    @Override
    public void registrar(Clientes cliente) throws Exception {
        try {
            //this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO users(name, last_name_p, last_name_m, domicilio, tel) VALUES(?,?,?,?,?);");
            st.setString(1, cliente.getNombre());
            st.setString(2, cliente.getApellidoP());
            st.setString(3, cliente.getApellidoM());
            st.setString(4, cliente.getDomicilio());
            st.setString(5, cliente.getTelefono());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            //this.Cerrar();
        }
    }

    @Override
    public void modificar(Clientes cliente) throws Exception {
        try {
            //this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("UPDATE users SET name = ?, last_name_p = ?, last_name_m = ?, domicilio = ?, tel = ? WHERE id = ?");
            st.setString(1, cliente.getNombre());
            st.setString(2, cliente.getApellidoP());
            st.setString(3, cliente.getApellidoM());
            st.setString(4, cliente.getDomicilio());
            st.setString(5, cliente.getTelefono());
            st.setInt(6, cliente.getId());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            //this.Cerrar();
        }
    }

    @Override
    public void eliminar(int idCliente) throws Exception {
        try {
            //this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("DELETE FROM users WHERE id = ?;");
            st.setInt(1, idCliente);
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            //this.Cerrar();
        }
    }

    @Override
    public List<Clientes> listar(String nombre) throws Exception {
        List<Clientes> lista = null;
        try {
            //this.Conectar();
            String Query = nombre.isEmpty() ? "SELECT * FROM users;" : "SELECT * FROM users WHERE name LIKE '%" + nombre + "%';";
            PreparedStatement st = this.conexion.prepareStatement(Query);
            
            lista = new ArrayList();
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                Clientes cliente = new Clientes();
                cliente.setId(rs.getInt("id"));
                cliente.setNombre(rs.getString("name"));
                cliente.setApellidoP(rs.getString("last_name_p"));
                cliente.setApellidoM(rs.getString("last_name_m"));
                cliente.setDomicilio(rs.getString("domicilio"));
                cliente.setTelefono(rs.getString("tel"));
                cliente.setSanciones(rs.getInt("sanctions"));
                cliente.setSanc_money(rs.getInt("sanc_money"));
                lista.add(cliente);
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            //this.Cerrar();
        }
        return lista;
    }

    @Override
    public Clientes getUserById(int idCliente) throws Exception {
        Clientes cliente = null;
        
        try {
            //this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM users WHERE id = ? LIMIT 1;");
            st.setInt(1, idCliente);
            
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                cliente = new Clientes();
                cliente.setId(rs.getInt("id"));
                cliente.setNombre(rs.getString("name"));
                cliente.setApellidoP(rs.getString("last_name_p"));
                cliente.setApellidoM(rs.getString("last_name_m"));
                cliente.setDomicilio(rs.getString("domicilio"));
                cliente.setTelefono(rs.getString("tel"));
                cliente.setSanciones(rs.getInt("sanctions"));
                cliente.setSanc_money(rs.getInt("sanc_money"));
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            //this.Cerrar();
        }
        return cliente;
    }

    @Override
    public void sancionar(Clientes cliente) throws Exception {
        try {
            //this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("UPDATE users SET sanctions = ?, sanc_money = ? WHERE id = ?");
            st.setInt(1, cliente.getSanciones());
            st.setInt(2, cliente.getSanc_money());
            st.setInt(3, cliente.getId());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            //this.Cerrar();
        }
    }
    
}
