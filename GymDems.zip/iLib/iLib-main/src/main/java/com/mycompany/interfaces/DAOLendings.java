package com.mycompany.interfaces;

import com.mycompany.clases.Productos;
import com.mycompany.clases.Prestamos;
import com.mycompany.clases.Clientes;
import java.util.List;

public interface DAOLendings {
    public void registrar(Prestamos lending) throws Exception;
    public void modificar(Prestamos lending) throws Exception;
    public Prestamos getLending(Clientes user, Productos book) throws Exception;
    // public void eliminar(Lendings user) throws Exception;
    public List<Prestamos> listar() throws Exception;
}
