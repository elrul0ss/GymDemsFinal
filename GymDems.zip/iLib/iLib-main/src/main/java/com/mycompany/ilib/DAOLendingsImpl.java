package com.mycompany.ilib;

import com.mycompany.db.Database;
import com.mycompany.interfaces.DAOLendings;
import com.mycompany.clases.Productos;
import com.mycompany.clases.Prestamos;
import com.mycompany.clases.Clientes;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DAOLendingsImpl extends Database implements DAOLendings {

    @Override
    public void registrar(Prestamos lending) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("INSERT INTO lendings(user_id, book_id, date_out) VALUES(?,?,?);");
            st.setInt(1, lending.getIdCliente());
            st.setInt(2, lending.getIdProducto());
            st.setString(3, lending.getFechaPrestamo());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public void modificar(Prestamos lending) throws Exception {
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("UPDATE lendings SET user_id = ?, book_id = ?, date_out = ?, date_return = ? WHERE id = ?");
            st.setInt(1, lending.getIdCliente());
            st.setInt(2, lending.getIdProducto());
            st.setString(3, lending.getFechaPrestamo());
            st.setString(4, lending.getFechaDevolucion());
            st.setInt(5, lending.getId());
            st.executeUpdate();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
    }

    @Override
    public Prestamos getLending(Clientes user, Productos book) throws Exception {
        Prestamos lending = null;
        
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM lendings WHERE user_id = ? AND book_id = ? AND date_return IS NULL ORDER BY id DESC LIMIT 1");
            st.setInt(1, user.getId());
            st.setInt(2, book.getId());
            
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                lending = new Prestamos();
                lending.setId(rs.getInt("id"));
                lending.setIdCliente(rs.getInt("user_id"));
                lending.setIdProducto(rs.getInt("book_id"));
                lending.setFechaPrestamo(rs.getString("date_out"));
                lending.setFechaDevolucion(rs.getString("date_return"));
            }
            
            st.close();
            rs.close();
        } catch (Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        
        return lending;
    }

    @Override
    public List<Prestamos> listar() throws Exception {
        List<Prestamos> lista = null;
        try {
            this.Conectar();
            PreparedStatement st = this.conexion.prepareStatement("SELECT * FROM lendings ORDER BY id DESC");
            
            lista = new ArrayList();
            ResultSet rs = st.executeQuery();
            while(rs.next()) {
                Prestamos lending = new Prestamos();
                lending.setId(rs.getInt("id"));
                lending.setIdCliente(rs.getInt("user_id"));
                lending.setIdProducto(rs.getInt("book_id"));
                lending.setFechaPrestamo(rs.getString("date_out"));
                lending.setFechaDevolucion(rs.getString("date_return"));
                lista.add(lending);
            }
            rs.close();
            st.close();
        } catch(Exception e) {
            throw e;
        } finally {
            this.Cerrar();
        }
        return lista;
    }

}
