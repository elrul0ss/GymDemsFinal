package com.mycompany.interfaces;

import com.mycompany.clases.Productos;
import java.util.List;

public interface DAOBooks {
    public void registrar(Productos book) throws Exception;
    public void modificar(Productos book) throws Exception;
    public void eliminar(int bookId) throws Exception;
    public List<Productos> listar(String title) throws Exception;
    public Productos getBookById(int bookId) throws Exception;
}
