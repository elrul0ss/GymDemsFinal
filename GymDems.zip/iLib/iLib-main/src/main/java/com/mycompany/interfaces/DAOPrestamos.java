package com.mycompany.interfaces;

import com.mycompany.clases.Productos;
import com.mycompany.clases.Prestamos;
import com.mycompany.clases.Clientes;
import java.util.List;

public interface DAOPrestamos {
    public void registrar(Prestamos prestamo) throws Exception;
    public void modificar(Prestamos prestamo) throws Exception;
    public Prestamos getLending(Clientes cliente, Productos producto) throws Exception;
    // public void eliminar(Lendings user) throws Exception;
    public List<Prestamos> listar() throws Exception;
}
