package com.mycompany.interfaces;

import com.mycompany.clases.Clientes;
import java.util.List;

public interface DAOUsers {
    public void registrar(Clientes user) throws Exception;
    public void modificar(Clientes user) throws Exception;
    public void sancionar(Clientes user) throws Exception;
    public void eliminar(int userId) throws Exception;
    public List<Clientes> listar(String name) throws Exception;
    public Clientes getUserById(int userId) throws Exception;
}