package com.mycompany.interfaces;

import com.mycompany.clases.Productos;
import java.util.List;

public interface DAOProductos {
    public void registrar(Productos producto) throws Exception;
    public void modificar(Productos producto) throws Exception;
    public void eliminar(int idProducto) throws Exception;
    public List<Productos> listar(String nombre) throws Exception;
    public Productos getBookById(int idProducto) throws Exception;
}
